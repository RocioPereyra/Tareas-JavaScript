//Punto 1
let num1 = parseInt(prompt("Ingrese el primer número"));
let num2 = parseInt(prompt("Ingrese el segundo número"));

if (num1 > num2) {
  console.log(num1 + num2);
}
if (num1 < num2) {
  console.log(num2 - num1);
}
if (num1 === num2) {
  console.log(num2 * num1);
}

//Punto 2
switch (false) {
  case num1===isNaN:
    console.error(0)
    break;

  default:
    console.log('Si es un número')
    break;
}
